import { useSyncExternalStore } from "react";

let open = false;
const listeners = new Set<() => void>();

const emit = () => listeners.forEach((l) => l());

export const openBooking = () => {
  open = true;
  if (typeof document !== "undefined") document.body.style.overflow = "hidden";
  emit();
};

export const closeBooking = () => {
  open = false;
  if (typeof document !== "undefined") document.body.style.overflow = "";
  emit();
};

export function useBookingOpen() {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => open,
    () => false
  );
}

export const BOOKING_WIDGET =
  "https://go.thesalondr.com.au/widget/booking/4gdDSPV7N5xjYc8gtOWS";
export const BOOKING_SCRIPT = "https://go.thesalondr.com.au/js/form_embed.js";
export const BOOKING_IFRAME_ID = "4gdDSPV7N5xjYc8gtOWS_1792858110431";
