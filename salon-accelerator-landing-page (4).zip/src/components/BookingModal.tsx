import { useEffect } from "react";
import {
  BOOKING_IFRAME_ID,
  BOOKING_SCRIPT,
  BOOKING_WIDGET,
  closeBooking,
  useBookingOpen,
} from "../booking";

function ensureEmbedScript() {
  if (document.querySelector(`script[src="${BOOKING_SCRIPT}"]`)) return;
  const script = document.createElement("script");
  script.src = BOOKING_SCRIPT;
  script.async = true;
  document.body.appendChild(script);
}

/** Keep the widget visible and scrollable without the blank stretch underneath. */
function fitFrame(frame: HTMLIFrameElement) {
  const hidden =
    frame.style.visibility === "hidden" ||
    frame.style.opacity === "0" ||
    frame.style.left === "-9999px";
  if (
    !hidden &&
    frame.getAttribute("scrolling") === "yes" &&
    frame.style.height === "100%" &&
    frame.style.minHeight === "0px"
  ) {
    return;
  }
  frame.style.visibility = "visible";
  frame.style.opacity = "1";
  frame.style.position = "relative";
  frame.style.left = "0";
  frame.style.top = "0";
  frame.style.width = "100%";
  frame.style.maxWidth = "100%";
  frame.style.height = "100%";
  frame.style.minHeight = "0";
  frame.style.maxHeight = "100%";
  frame.style.display = "block";
  frame.style.overflow = "auto";
  frame.style.border = "0";
  frame.setAttribute("scrolling", "yes");
}

export function BookingModal() {
  const open = useBookingOpen();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeBooking();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!open) return;
    ensureEmbedScript();

    const apply = () => {
      const el = document.getElementById(BOOKING_IFRAME_ID);
      if (el instanceof HTMLIFrameElement) fitFrame(el);
    };

    apply();
    const observer = new MutationObserver(apply);
    const watch = window.setInterval(() => {
      const el = document.getElementById(BOOKING_IFRAME_ID);
      if (!(el instanceof HTMLIFrameElement)) return;
      observer.observe(el, {
        attributes: true,
        attributeFilter: ["style", "scrolling", "height"],
      });
      apply();
    }, 400);
    const stopWatch = window.setTimeout(() => window.clearInterval(watch), 10000);

    return () => {
      window.clearInterval(watch);
      window.clearTimeout(stopWatch);
      observer.disconnect();
    };
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-ink/70 p-3 backdrop-blur-sm sm:p-6">
      <div className="flex h-[min(460px,72dvh)] w-full max-w-3xl flex-col overflow-hidden rounded-[1.5rem] bg-white shadow-2xl sm:h-[min(560px,78dvh)]">
        <div className="flex shrink-0 items-center justify-between gap-4 border-b border-sand px-4 py-3 sm:px-5">
          <div className="min-w-0">
            <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-rose-deep">
              The Salon Dr.
            </div>
            <h2 className="truncate font-display text-lg leading-tight sm:text-xl">
              Book a discovery call
            </h2>
          </div>
          <button
            onClick={closeBooking}
            aria-label="Close booking calendar"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-sand text-ink transition hover:bg-rose"
          >
            ✕
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-hidden">
          <iframe
            src={BOOKING_WIDGET}
            id={BOOKING_IFRAME_ID}
            title="Book a discovery call with Sonia Tomas"
            allow="payment"
            scrolling="yes"
            className="block h-full w-full border-0"
          />
        </div>
      </div>
    </div>
  );
}
